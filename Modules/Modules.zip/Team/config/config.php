<?php

return [
    'name' => 'Team',
];
