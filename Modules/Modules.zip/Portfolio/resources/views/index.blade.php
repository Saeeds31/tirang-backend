<x-portfolio::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('portfolio.name') !!}</p>
</x-portfolio::layouts.master>
