<?php

namespace Modules\History\Database\Seeders;

use Illuminate\Database\Seeder;

class HistoryDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
