<x-history::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('history.name') !!}</p>
</x-history::layouts.master>
