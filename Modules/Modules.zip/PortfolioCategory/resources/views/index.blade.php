<x-portfoliocategory::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('portfoliocategory.name') !!}</p>
</x-portfoliocategory::layouts.master>
