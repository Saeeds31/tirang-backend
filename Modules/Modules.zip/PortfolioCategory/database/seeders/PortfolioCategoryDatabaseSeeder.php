<?php

namespace Modules\PortfolioCategory\Database\Seeders;

use Illuminate\Database\Seeder;

class PortfolioCategoryDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
